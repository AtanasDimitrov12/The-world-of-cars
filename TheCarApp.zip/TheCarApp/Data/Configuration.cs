﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-IL35000\SQLEXPRESS;Database=CarApp;Integrated Security=true;TrustServerCertificate=True";
    }
}
