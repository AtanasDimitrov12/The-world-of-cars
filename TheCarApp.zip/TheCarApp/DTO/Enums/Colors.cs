﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.Enums
{
    public enum Colors
    {
        BLACK,
        BLUE,
        RED,
        WHITE,
        GREEN,
        YELLOW,
        ORANGE,
        PURPLE,
        PINK,
        BROWN,
        GRAY,
        CYAN,
        MAGENTA,
        MAROON,
        NAVY,
        LIME,
        OLIVE,
        TEAL,
        AQUA,
        SILVER,
        GOLD,
        BRONZE,
        VIOLET
    }
}
